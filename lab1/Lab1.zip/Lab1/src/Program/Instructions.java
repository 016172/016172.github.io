package Program;
import Computer.*;

public interface Instructions {

    String toString();

    void execute(Memory mem, ProgramCounter PC);
}
