package Program;
import Computer.*;

public class Print implements Instructions{

    Address t1;

    public Print(Address get) {
        t1 = get;
    }

    private String getem(Memory t)
    {
       return t1.getWord(t).toString();
    }

    @Override
    public void execute(Memory t, ProgramCounter PC) {
       getem(t);
    }
}
