package Program;
import Computer.*;

public abstract class BinOp implements Instructions {

    private WordOrAddress t1;
    private WordOrAddress t2;
    private Address t3;

    private Word t4;
    private Word t5;
    private Word t6;

    public BinOp(WordOrAddress leftValue, WordOrAddress rightValue, Address ref)
    {
       t1 = leftValue;
       t2 = rightValue;
       t3 = ref;
    }

    public void Convert(Memory t) {
        t4 = t1.getWord(t);
        t5 = t2.getWord(t);
        t6 = t3.getWord(t);

    }

    public void PerformFinalAction(){
        doFinalOperand(t4,t5,t6);
    }

    abstract void doFinalOperand(Word left, Word right, Word storage);


    @Override
    public void execute(Memory mem, ProgramCounter PC) {


    }
}
