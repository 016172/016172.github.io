package Program;

import Computer.Address;
import Computer.Memory;
import Computer.Word;
import Computer.WordOrAddress;

public class Mul extends BinOp{

    public Mul(WordOrAddress leftValue, WordOrAddress rightValue, Address ref) {
        super(leftValue,rightValue,ref);
    }

    @Override
    void doFinalOperand(Word left, Word right, Word storage) {
        storage.mul(left,right);
    }

}
