package Program;

import Computer.*;

public class Add extends BinOp {
    int left;
    int right;

    public Add(WordOrAddress leftValue, WordOrAddress rightValue, Address ref)
    {
        super(leftValue,rightValue,ref);
    }


   public void doFinalOperand(Word left, Word right, Word storage) {
        storage.add(left,right);
    }

    public void adding(Word left, Word right, Word savedValue)
    {
       savedValue.add(left,right);
    }




}
