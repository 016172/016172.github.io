package Program;

import Computer.*;

import java.util.ArrayList;

public class Program{
    ArrayList<Instructions> commands;
    ProgramCounter machine;


    public Program()
    {
      machine = new ProgramCounter();
      commands = new ArrayList<Instructions>();
    }

    public void add(Instructions instruction)
    {
        commands.add(instruction);
    }

    public void execute(){
        commands.get(machine.pos);
        machine.increaseByOne();

    }
}
