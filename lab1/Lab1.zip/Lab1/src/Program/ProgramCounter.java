package Program;

public class ProgramCounter {
    public int pos;

    public ProgramCounter()
    {
        pos = 0; //variabeln får värdet 0, längst fram i listan.
    }

    public void setValue(int incr)
    {
        pos = incr; //Om vi vill hoppa till en specifik instruktion på plats 'incr'.
    }

    public void increaseByOne()
    {
        this.pos++; //Efter varje instruktion ska vi öka positionen i listan för våra instruktioner
    }
}
