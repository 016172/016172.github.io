package Computer;

public interface WordFactory {

    Word word(String value);
}
