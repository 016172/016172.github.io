package Computer;

public class Memory  {
        public Word[] memorize;
        private int size;

    public Memory(int size, WordFactory fac){
        if(size > 0)
        {
            this.size = size;
            memorize = new Word[size];
        }
        else {
            throw new ExceptionInInitializerError("Unable to initalize list");
        }

    }

    public Memory() {
    }

    public int getSize()
    {
        return size;
    }

    public Word get(int position)
    {
        return memorize[position];
    }
}
