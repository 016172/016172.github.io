package Computer;

import Program.*;

public class Computer{
    public Memory mem;
    private Program prog;

    public Computer(Memory memory){
        mem = memory;
    }

    public void load(Program program){
    prog = program;
    }

    public void run()
    {
        prog.execute();
    }
}
