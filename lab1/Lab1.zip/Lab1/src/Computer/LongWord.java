package Computer;

public class LongWord implements Word {
    private Long carry;

    public LongWord(String a)
    {
        carry = Long.parseLong(a);
    }


    public Word getWord() {
        return this;
    }

    public void mul(Word t1, Word t2) {
        carry = (Long.parseLong(t1.getWord().toString()) * Long.parseLong(t2.getWord().toString()));
    }


    public void add(Word t1, Word t2) {
        carry = (Long.parseLong(t1.getWord().toString()) + Long.parseLong(t2.getWord().toString()));
    }

    public void update(Word t){
        carry = Long.parseLong(t.toString());
    }
}
