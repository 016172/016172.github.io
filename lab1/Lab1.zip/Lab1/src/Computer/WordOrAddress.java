package Computer;

public interface WordOrAddress {

   Word getWord(Memory mem);
}
