package Computer;

public class ByteWordFactory implements WordFactory {

    public ByteWord word(String value) {
        return new ByteWord(value);
    }
}
