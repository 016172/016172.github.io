package Computer;

import Computer.*;

public class Address implements WordOrAddress {
    int reference;

    public Address(int ref)
    {
        this.reference = ref;
    }

    public int getIndex()
    {
        return reference;
    }

    public Word getWord(Memory mem) {
        return mem.get(reference);
    }
}
