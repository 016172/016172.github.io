package Computer;

public class ByteWord implements Word{
    private byte carry;

    public ByteWord(String value)
    {
        this.carry = Byte.parseByte(value);
    }

    public Word getWord() {
        return this;
    }


    public void add(Word t1, Word t2) {
        carry = (byte)(Byte.parseByte(t1.getWord().toString()) + Byte.parseByte(t2.getWord().toString()));
    }


    public void mul(Word t1, Word t2) {
        carry = (byte)(Byte.parseByte(t1.getWord().toString()) * Byte.parseByte(t2.getWord().toString()));
    }

    public void update(Word t){
        carry = Byte.parseByte(t.toString());
    }


}
