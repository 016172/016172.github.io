package Computer;

public interface Word{

     Word getWord();

    void add(Word t1, Word t2);

    void mul(Word t1, Word t2);

    void update(Word t);

    String toString();
}
